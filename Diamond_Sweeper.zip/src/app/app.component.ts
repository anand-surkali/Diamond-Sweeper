import { Component } from '@angular/core';
declare var jquery:any;
declare var $ :any;


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
constructor( ) { }


data= [
                ["unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "diamond", "unknown"],
                ["unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown"],
                ["diamond", "unknown", "unknown", "unknown", "diamond", "unknown", "unknown", "unknown"],
                ["unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown"],
                ["unknown", "unknown", "diamond", "unknown", "unknown", "diamond", "unknown", "unknown"],
                ["unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "diamond"],
                ["unknown", "unknown", "unknown", "unknown", "diamond", "unknown", "unknown", "unknown"],
                ["unknown", "diamond", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown"]
            ];

diamondPlaces=['06','20', '24', '42', '45','57', '64', '71']

visited= [
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false],
                [false, false, false, false, false, false, false, false]
            ];
row:number;
col:number;

diamond:number=0;        
count:number=0;


myfunction(row,col, e){
if(this.visited[row][col] == true){

	return false;
}

else{
	e.target.classList.remove('unknown')
	e.target.classList.add('disabled')
	this.visited[row][col] = true;
	console.log("visited" , this.visited[row][col]);
	if(this.data[row][col] == "diamond"){
	var index=this.diamondPlaces.indexOf(row.toString()+col.toString())
	this.diamondPlaces.splice(index,1);
			e.target.classList.add('diamond')
	this.diamond++

	console.log("this.diamond", this.diamond)
			if(this.diamond == 8){

				this.countFunction();
                $('div').removeClass('cell');
                $('div').addClass('disabled1');
			}
		}
		else{
                $('div').removeClass('arrow');

				var angle= this.showingHint(row,col);
				console.log("angle", angle);
				e.target.classList.add('arrow')
				e.target.style["transform"] = "rotate(" + angle + "deg)";
			}
		}
	}

showingArrow(row,col){
	var diamondDist = {};
	for (var i = 0; i < this.diamondPlaces.length; i++) {
		var diamondRow = (this.diamondPlaces[i]).substr(0,1);
		var diamondCol = (this.diamondPlaces[i]).substr(1,1);
		diamondDist[this.diamondPlaces[i]] = Math.abs(Number(row) - Number(diamondRow)) + Math.abs(Number(col) - Number(diamondCol));
	}

    return Object.keys(diamondDist).sort(function(a, b) {
    	console.log("hello");
        return diamondDist[a] - diamondDist[b]
    })[0];
	
}

showingHint(row,col) {
    var nearestDiamondId = this.showingArrow(row,col);
    console.log(nearestDiamondId);
		var neardiamondRow = (nearestDiamondId).substr(0,1);
		var neardiamondCol = (nearestDiamondId).substr(1,1);    
    return (Math.atan2((Number(neardiamondRow) - Number(row)), (Number(neardiamondCol) - Number(col)))) * 180 / Math.PI;
}

countFunction(){
	for(let i=0; i<= 8; i++){
			for(let j=0; j<= 8; j++){
					if(this.visited[i][j] == true){
							this.count++;
					}
					else{

			}

	}
}
}

refresh(): void {
    window.location.reload();
}



}

